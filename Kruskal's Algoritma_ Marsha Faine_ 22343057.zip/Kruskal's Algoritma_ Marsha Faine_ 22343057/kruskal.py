class Subset:
    def __init__(self, parent, rank):
        self.parent = parent
        self.rank = rank

def inisialisasi_subsets(n):
    subsets = []
    for i in range(n):
        subsets.append(Subset(i, 0))
    return subsets

def cari(subsets, i):
    if subsets[i].parent != i:
        subsets[i].parent = cari(subsets, subsets[i].parent)
    return subsets[i].parent

def gabung(subsets, x, y):
    root_x = cari(subsets, x)
    root_y = cari(subsets, y)

    if subsets[root_x].rank < subsets[root_y].rank:
        subsets[root_x].parent = root_y
    elif subsets[root_x].rank > subsets[root_y].rank:
        subsets[root_y].parent = root_x
    else:
        subsets[root_y].parent = root_x
        subsets[root_x].rank += 1

def kruskal(graph, V):
    result = []
    i = 0
    e = 0

    graph = sorted(graph, key=lambda item: item[2])

    subsets = inisialisasi_subsets(V)

    while e < V - 1:
        u, v, w = graph[i]
        i += 1
        x = cari(subsets, u)
        y = cari(subsets, v)

        if x != y:
            e += 1
            result.append((u, v, w))
            gabung(subsets, x, y)

    return result

# Contoh penggunaan
graph = [(0, 1, 11), (0, 2, 6), (0, 3, 8), (1, 3, 14), (2, 3, 7)]
V = 4  # Jumlah simpul

hasil = kruskal(graph, V)
print("Tepi dalam Minimum Spanning Tree:")
for u, v, w in hasil:
    print(f"Simpul {u} ke simpul {v} dengan bobot {w}")
